package Lab3.Demo.SpringBootApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class DemoPostApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPostApplication.class, args);
	}

}
