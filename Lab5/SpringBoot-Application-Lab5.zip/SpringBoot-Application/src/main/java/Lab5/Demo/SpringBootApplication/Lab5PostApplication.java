package Lab5.Demo.SpringBootApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Lab5PostApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab5PostApplication.class, args);
	}

}
