INSERT into POST (id, title, content, author) VALUES (101L, 'Covid-19 Update', 'New Covid Variant hits US', 'Sirak');
INSERT into POST (id, title, content, author) VALUES (102L, 'Book called Nateba do zareba official', 'Book Celebration', 'John');
INSERT into POST (id, title, content, author) VALUES (103L, 'Utopia Park will be Modified', 'Fairfield Iowa', 'Awet');
INSERT into POST (id, title, content, author)  VALUES (104L, 'Storm hits many states', 'Ida hits Vargina', 'Bruke');

