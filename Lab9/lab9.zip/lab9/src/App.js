import React, { Component } from 'react';

import Blog from './containers/Blog/Blog';

const App = () => {

    return (
      <div className="App">
        <Blog />
      </div>
    );
  }

export default App;
