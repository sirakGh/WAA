package miu.edu.springBoot.PostUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
