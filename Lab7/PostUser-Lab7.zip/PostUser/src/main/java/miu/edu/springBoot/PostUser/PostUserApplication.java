package miu.edu.springBoot.PostUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostUserApplication.class, args);
	}

}
